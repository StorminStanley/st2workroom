require 'spec_helper'

describe 'st2::package::install' do
  default_facts = {
      :virtual         => "ec2",
      :ipaddress       => "172.16.4.18",
      :osfamily        => "Debian",
      :operatingsystem => "Ubuntu",
      :lsbdistcodename => "precise",
      :hostname        => "rainbowmarh",
      :domain          => "stackstorm.net",
      :fqdn            => "rainbowmarh.stackstorm.net",
      :concat_basedir  => "/var/lib/puppet/concat",
  }

  let(:facts) { default_facts }
  let(:node) { "rainbowmarh.stackstorm.net" }
  let(:title) { 'st2api' }

  describe 'Installs dev version' do
    let(:params) {
      {
        :version  => '0.14dev',
        :revision => '88',
      }
    }

    it do
      should contain_package('st2api').with(
        :ensure => "0.14dev-88",
      )
    end

  end
end
