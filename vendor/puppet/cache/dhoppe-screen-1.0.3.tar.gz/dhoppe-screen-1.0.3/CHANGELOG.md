## 2015-02-25 Release 1.0.3
### Summary:
- [Beaker] Update Beaker environment
- [Travis CI] Update Travis CI environment

## 2015-02-25 Release 1.0.2
### Summary:
- [Beaker] Update Beaker environment
- [Puppet] Add support for Debian 8.x (Jessie)

## 2014-12-06 Release 1.0.1
### Summary:
- [Rspec] Made some changes to the build environment

## 2014-11-28 Release 1.0.0
### Summary:
- Generated from [https://github.com/dhoppe/puppet-skeleton-simple](https://github.com/dhoppe/puppet-skeleton-simple)
