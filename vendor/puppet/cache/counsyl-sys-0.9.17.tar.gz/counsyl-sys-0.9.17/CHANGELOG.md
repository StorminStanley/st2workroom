## 0.9.17 (04/08/2015)

IMPROVEMENTS:

* Updates for OpenBSD manifests (GH-4)

BUG FIXES:

* SELinux template location fix from Bill Weiss (GH-5)
