require 'puppetlabs_spec_helper/module_spec_helper'
require 'coveralls'

require_relative 'helpers/fact_helper'

Coveralls.wear!
